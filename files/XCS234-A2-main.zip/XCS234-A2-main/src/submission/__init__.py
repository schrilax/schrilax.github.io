from .q3_schedule import LinearSchedule, LinearExploration
from .q5_linear_torch import Linear
from .q6_dqn_torch import NatureQN